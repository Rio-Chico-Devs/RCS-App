class Materiale:
    def __init__(self, nome="", spessore=0.0, prezzo=0.0, fornitore="", prezzo_fornitore=0.0, capacita_magazzino=0.0, giacenza=0.0, categoria_id=None):
        self.nome = nome
        self.spessore = spessore
        self.prezzo = prezzo
        self.fornitore = fornitore
        self.prezzo_fornitore = prezzo_fornitore
        self.capacita_magazzino = capacita_magazzino
        self.giacenza = giacenza
        self.categoria_id = categoria_id

class MaterialeCalcolato:
    def __init__(self):
        # Sezione sviluppo
        self.diametro = 0.0
        self.lunghezza = 0.0
        self.materiale_id = None
        self.materiale_nome = ""
        self.giri = 0
        self.spessore = 0.0  # Dal materiale selezionato
        self.diametro_finale = 0.0  # Calcolato
        self.sviluppo = 0.0  # Calcolato
        self.arrotondamento_manuale = 0.0

        # Sezione costo materiale
        self.costo_materiale = 0.0  # Dal materiale selezionato
        self.lunghezza_utilizzata = 0.0  # Calcolato
        self.costo_totale = 0.0  # Calcolato
        self.maggiorazione = 0.0  # Calcolato

        # Aggiungo anche un alias per compatibilità con il codice esistente
        self.prezzo = 0.0  # Alias per costo_materiale

        # Modalità conica
        self.is_conica = False
        self.sezioni_coniche = []  # Mantenuto per retrocompatibilità

        # Conicità semplificata: lato, altezza inizio taglio, lunghezza taglio
        self.conicita_lato = 'sinistra'       # 'sinistra', 'destra', 'entrambi'
        self.conicita_altezza_mm = 0.0        # mm dall'alto sul bordo laterale (0 = angolo)
        self.conicita_lunghezza_mm = 0.0      # mm estensione orizzontale del taglio

        # Scarto materiale (mm²) - solo per conica
        self.scarto_mm2 = 0.0

        # Orientamento (da toolbar rotate/flip della TelaPreviewWidget)
        self.orientamento = {'rotation': 0, 'flip_h': False, 'flip_v': False}

    @property
    def stratifica(self):
        """Alias per sviluppo - per compatibilità con codice esistente"""
        return self.sviluppo

    @stratifica.setter
    def stratifica(self, value):
        """Setter per l'alias stratifica"""
        self.sviluppo = value

    def calcola_diametro_finale(self):
        """Calcola il diametro finale (sempre cilindrico; la conica è solo visiva)"""
        self.diametro_finale = self.diametro + (self.spessore * (self.giri * 2))
        return self.diametro_finale

    def calcola_sviluppo(self):
        """Calcola lo sviluppo (sempre cilindrico; la conica è solo visiva)"""
        if self.arrotondamento_manuale > 0:
            self.sviluppo = self.arrotondamento_manuale
        else:
            self.sviluppo = ((self.diametro + self.giri * self.spessore) * 3.14) * self.giri + 5
        return self.sviluppo

    def calcola_stratifica(self):
        """Alias per calcola_sviluppo - per compatibilità"""
        return self.calcola_sviluppo()

    def calcola_lunghezza_utilizzata(self):
        """Calcola lunghezza utilizzata in m² (sempre cilindrico; la conica è solo visiva)"""
        if self.sviluppo > 0:
            self.lunghezza_utilizzata = (self.lunghezza * self.sviluppo) / 1000000
        return self.lunghezza_utilizzata

    def calcola_costo_totale(self):
        """Calcola costo totale: lunghezza_utilizzata * costo_materiale"""
        if self.prezzo > 0:
            self.costo_materiale = self.prezzo
        self.costo_totale = self.lunghezza_utilizzata * self.costo_materiale
        return self.costo_totale

    def calcola_maggiorazione(self):
        """Calcola maggiorazione: costo_totale * 1.1"""
        self.maggiorazione = self.costo_totale * 1.1
        return self.maggiorazione

    def ricalcola_tutto(self):
        """Ricalcola tutti i valori derivati"""
        self.calcola_diametro_finale()
        self.calcola_sviluppo()
        self.calcola_lunghezza_utilizzata()
        self.calcola_costo_totale()
        self.calcola_maggiorazione()

    def to_dict(self):
        """Converte l'oggetto in dizionario per il salvataggio"""
        d = {
            'diametro': self.diametro,
            'lunghezza': self.lunghezza,
            'materiale_id': self.materiale_id,
            'materiale_nome': self.materiale_nome,
            'giri': self.giri,
            'spessore': self.spessore,
            'diametro_finale': self.diametro_finale,
            'sviluppo': self.sviluppo,
            'stratifica': self.sviluppo,  # Per compatibilità
            'arrotondamento_manuale': self.arrotondamento_manuale,
            'costo_materiale': self.costo_materiale,
            'lunghezza_utilizzata': self.lunghezza_utilizzata,
            'costo_totale': self.costo_totale,
            'maggiorazione': self.maggiorazione,
            'is_conica': self.is_conica,
            'sezioni_coniche': self.sezioni_coniche,
            'conicita_lato': self.conicita_lato,
            'conicita_altezza_mm': self.conicita_altezza_mm,
            'conicita_lunghezza_mm': self.conicita_lunghezza_mm,
            'scarto_mm2': self.scarto_mm2,
            'orientamento': self.orientamento
        }
        return d