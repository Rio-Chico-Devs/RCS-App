================================================================================
FILE MODIFICATI - RCS APP v2.4.0
Sistema di Versioning Git-like + Campo Misura + Layout Riformattato
================================================================================

Data: 07/02/2026
Branch: claude/add-quote-comparison-wqe0l
Commit: 2756c8a

CONTENUTO DELLO ZIP:
--------------------

1. database/db_manager.py (630 righe)
   - AGGIUNTO: Campo 'misura' nella tabella preventivi
   - AGGIUNTO: Campo storico_modifiche nella tabella preventivi
   - AGGIUNTO: Metodo get_storico_modifiche()
   - AGGIUNTO: Metodo ripristina_versione_preventivo()
   - AGGIUNTO: Metodo get_preventivi_con_modifiche()
   - MODIFICATO: update_preventivo() ora salva snapshot prima di aggiornare
   - MODIFICATO: Tutti i metodi CRUD includono campo 'misura'
   - Migrazione automatica del database per retrocompatibilità

2. ui/visualizza_preventivi_window.py (881 righe)
   - RIMOSSO: Toggle Preventivi/Revisioni (mostra sempre tutti)
   - AGGIUNTO: Filtro "Tipo" sempre visibile
   - AGGIUNTO: Campo Misura nella visualizzazione
   - MODIFICATO: Layout lista completamente riformattato
   - Formato nuovo: #ID [Tipo] - Cliente: NOME
                    Misura: XXX | Descrizione: YYY
   - Tipo tra parentesi: [Originale]/[Revisionato]/[Con modifiche]
   - Badge modifiche: [Originale/Con modifiche]
   - Integrazione completa con sistema di versioning

3. ui/preventivo_window.py (1207 righe)
   - AGGIUNTO: Campo "Misura" nel form (sotto Numero Ordine)
   - Seconda riga ora: Codice | Misura
   - Salvataggio e caricamento completo del campo misura
   - Disabilitazione campo in modalità visualizza

4. ui/visualizza_modifiche_dialog.py (509 righe) - NUOVO FILE
   - Dialog dedicato per visualizzare storico modifiche
   - Lista versioni con timestamp
   - Visualizzazione dettagli di ogni versione
   - Confronto tra versione selezionata e corrente
   - Ripristino versione precedente con conferma

5. ui/main_window.py (111 righe)
   - Struttura refactorizzata con logica separata
   - Mantiene compatibilità con codice esistente

6. ui/main_window_business_logic.py (631 righe)
   - Logica di business separata per manutenibilità
   - Gestione completa preventivi e documenti

7. ui/main_window_ui_components.py (297 righe)
   - Componenti UI standardizzati
   - Design system unificato

FUNZIONALITÀ IMPLEMENTATE:
--------------------------

✅ Campo "Misura" aggiunto ai preventivi
✅ Sistema di versioning Git-like per preventivi
✅ Storico modifiche con timestamp e snapshot completi
✅ Visualizzazione modifiche in dialog dedicato
✅ Confronto tra versioni (side-by-side)
✅ Ripristino versione precedente
✅ Filtro "Con modifiche" per identificare preventivi modificati
✅ Layout lista COMPLETAMENTE riformattato e più leggibile
✅ Filtro Tipo sempre visibile (non più nascosto)
✅ RIMOSSO toggle Preventivi/Revisioni (mostra sempre tutti)
✅ Integrazione completa con flusso esistente
✅ Migrazione automatica database per retrocompatibilità

NOVITÀ RISPETTO ALLA VERSIONE PRECEDENTE:
------------------------------------------

1. CAMPO MISURA:
   - Nuovo campo obbligatorio nel form preventivo
   - Visibile nella lista preventivi
   - Salvato nel database con migrazione automatica

2. VISUALIZZAZIONE LISTA RIFORMATTATA:

   PRIMA (confuso e troppo testo):
   -----------------------------------
   #030 [Revisionato] - 2026-02-05 - es composite | ORD123
   Preventivo: EUR 106.95 | Cliente: EUR 16.25
   Descrizione: Preventivo per lavori speciali...

   DOPO (pulito e organizzato):
   -----------------------------------
   #030 [Revisionato/Con modifiche] - Cliente: es composite
   Misura: 500x300 | Descrizione: Preventivo per lavori speciali...

3. FILTRO TIPO SEMPRE VISIBILE:
   - Prima era nascosto e si mostrava solo in modalità "Revisioni"
   - Ora è sempre disponibile con opzioni: Tutti, Originali, Revisionati, Con modifiche

4. TOGGLE RIMOSSO:
   - Eliminato completamente il toggle Preventivi/Revisioni
   - Mostra sempre TUTTI i preventivi
   - Filtraggio tramite dropdown "Tipo"

INSTALLAZIONE:
--------------

1. Estrai i file mantenendo la struttura delle directory
2. Sostituisci i file esistenti nella tua installazione RCS-App
3. Al primo avvio, il database verrà automaticamente migrato
   (verrà aggiunta la colonna 'misura' se non presente)
4. Testa le nuove funzionalità in ambiente di sviluppo prima della produzione

NOTA IMPORTANTE:
----------------

- Il sistema salva automaticamente snapshot PRIMA di ogni modifica
- Non elimina mai dati: ogni versione viene conservata nello storico
- Lo storico è memorizzato come JSON nel campo storico_modifiche
- Il campo "misura" è retrocompatibile: preventivi esistenti avranno valore vuoto

COMPATIBILITÀ:
--------------

- ✅ Retrocompatibile con database esistenti
- ✅ Migrazione automatica al primo avvio
- ✅ Tutti i preventivi esistenti continuano a funzionare
- ✅ Le nuove funzionalità sono disponibili solo per preventivi modificati
- ✅ Campo misura opzionale (può essere lasciato vuoto)

TESTING:
--------

1. TEST CAMPO MISURA:
   - Crea un nuovo preventivo
   - Compila il campo "Misura" (es: 500x300)
   - Salva e verifica che appaia nella lista

2. TEST VERSIONING:
   - Apri un preventivo esistente
   - Modificalo (es. cambia prezzo cliente o aggiungi materiale)
   - Salva le modifiche
   - Vai in "Visualizza Preventivi"
   - Verifica che appaia [Originale/Con modifiche] o [Revisionato/Con modifiche]
   - Clicca su "Visualizza Modifiche"
   - Naviga nello storico e prova il confronto/ripristino

3. TEST FILTRI:
   - Seleziona "Tipo: Tutti" → mostra tutti
   - Seleziona "Tipo: Originali" → solo preventivi con revisione = 1
   - Seleziona "Tipo: Revisionati" → solo preventivi con revisione > 1
   - Seleziona "Tipo: Con modifiche" → solo preventivi con storico modifiche

4. TEST LAYOUT:
   - Verifica che ogni preventivo mostri:
     * Riga 1: #ID [Tipo] - Cliente: NOME
     * Riga 2: Misura: XXX | Descrizione: YYY
   - Verifica che il tipo sia tra parentesi quadre
   - Verifica che badge "Con modifiche" appaia quando presente

STRUTTURA DATABASE:
-------------------

Tabella preventivi (campi aggiornati):
- id (INTEGER PRIMARY KEY)
- data_creazione (TEXT)
- numero_revisione (INTEGER DEFAULT 1)
- preventivo_originale_id (INTEGER, FK)
- nome_cliente (TEXT)
- numero_ordine (TEXT)
- misura (TEXT) ← NUOVO
- descrizione (TEXT)
- codice (TEXT)
- [... altri campi numerici ...]
- storico_modifiche (TEXT, JSON) ← NUOVO

FORMATO STORICO MODIFICHE (JSON):
----------------------------------

[
  {
    "timestamp": "2026-02-07T14:30:00",
    "data": {
      "nome_cliente": "Cliente XYZ",
      "numero_ordine": "ORD123",
      "misura": "500x300",
      "descrizione": "...",
      "prezzo_cliente": 100.50,
      ...
    }
  },
  ...
]

Per domande o supporto, contatta il team di sviluppo.

================================================================================
