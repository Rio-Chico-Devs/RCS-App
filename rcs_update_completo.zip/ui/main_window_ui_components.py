#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
© 2025 RCS - Software Proprietario
Main Window UI Components - Componenti dell'interfaccia utente per MainWindow
Uso riservato esclusivamente a RCS

Version: 1.0.0
Last Updated: 24/09/2025
Author: Antonio VB
"""

# type: ignore
# pyright: reportUnknownParameterType=false, reportMissingParameterType=false
# pyright: reportUnknownMemberType=false, reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false, reportAttributeAccessIssue=false
# pyright: reportUnusedVariable=false
# type: ignore
# pyright: reportUnusedImport=false
# type: ignore
# pyright: reportUnknownLambdaType=false

from PyQt5.QtWidgets import (QVBoxLayout, QHBoxLayout, QPushButton, QWidget,
                             QLabel, QGroupBox, QFrame, QSizePolicy,
                             QGraphicsDropShadowEffect, QScrollArea, QApplication)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QColor

class MainWindowUIComponents:
    
    @staticmethod
    def init_ui(window_instance):
        """Inizializzazione completa dell'interfaccia MainWindow"""
        window_instance.setWindowTitle("Software Aziendale RCS")

        # Applica stili globali
        MainWindowUIComponents.apply_global_styles(window_instance)

        # Widget centrale con scroll — si adatta a qualsiasi risoluzione
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area.setStyleSheet("QScrollArea { background-color: #fafbfc; border: none; }")
        window_instance.setCentralWidget(scroll_area)

        inner_widget = QWidget()
        inner_widget.setStyleSheet("background-color: #fafbfc;")
        scroll_area.setWidget(inner_widget)

        # Calcola margini adattivi in base all'altezza dello schermo
        screen = QApplication.primaryScreen().availableGeometry()
        if screen.height() <= 800:
            h_margin, v_margin, spacing = 24, 16, 16
        else:
            h_margin, v_margin, spacing = 40, 30, 30

        main_layout = QVBoxLayout(inner_widget)
        main_layout.setContentsMargins(h_margin, v_margin, h_margin, v_margin)
        main_layout.setSpacing(spacing)

        # Header principale
        MainWindowUIComponents.create_header(window_instance, main_layout)

        # Contenuto principale
        content_layout = QHBoxLayout()
        content_layout.setSpacing(spacing)
        MainWindowUIComponents.create_main_actions_column(window_instance, content_layout)
        main_layout.addLayout(content_layout, 1)

        # Footer informativo
        MainWindowUIComponents.create_footer(window_instance, main_layout)
    
    @staticmethod
    def apply_global_styles(window_instance):
        """Applica stili globali unificati"""
        window_instance.setStyleSheet("""
            QMainWindow {
                background-color: #fafbfc;
            }
            QLabel {
                color: #2d3748;
                font-family: system-ui, -apple-system, sans-serif;
                font-size: 14px;
                font-weight: 500;
            }
            QGroupBox {
                font-size: 16px;
                font-weight: 600;
                color: #4a5568;
                border: none;
                background-color: #ffffff;
                border-radius: 12px;
                margin-top: 16px;
                padding-top: 16px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 20px;
                padding: 6px 0px;
                background-color: transparent;
                color: #4a5568;
            }
            QListWidget {
                background-color: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 8px;
                font-size: 14px;
                padding: 8px;
                font-family: system-ui, -apple-system, sans-serif;
            }
            QListWidget::item {
                border-radius: 6px;
                padding: 12px;
                margin: 2px 0px;
                border-bottom: 1px solid #f7fafc;
                color: #2d3748;
            }
            QListWidget::item:hover {
                background-color: #f7fafc;
            }
            QListWidget::item:selected {
                background-color: #edf2f7;
                color: #2d3748;
            }
            QPushButton {
                border: none;
                border-radius: 6px;
                font-size: 14px;
                font-weight: 600;
                padding: 12px 24px;
                font-family: system-ui, -apple-system, sans-serif;
            }
        """)
    
    @staticmethod
    def create_shadow_effect(blur=10, opacity=12):
        """Effetto ombra standardizzato"""
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(blur)
        shadow.setColor(QColor(0, 0, 0, opacity))
        shadow.setOffset(0, 2)
        return shadow
    
    @staticmethod
    def create_header(window_instance, parent_layout):
        """Header unificato con titolo principale"""
        screen = QApplication.primaryScreen().availableGeometry()
        small_screen = screen.height() <= 800

        header_container = QFrame()
        padding = "10px 0px" if small_screen else "20px 0px"
        header_container.setStyleSheet(f"""
            QFrame {{
                background-color: transparent;
                border: none;
                padding: {padding};
            }}
        """)

        header_layout = QVBoxLayout(header_container)
        header_layout.setSpacing(4 if small_screen else 8)

        title_size = "24px" if small_screen else "32px"
        title_label = QLabel("Software Aziendale RCS")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet(f"""
            QLabel {{
                font-size: {title_size};
                font-weight: 700;
                color: #2d3748;
                padding: 0;
            }}
        """)

        subtitle_size = "13px" if small_screen else "16px"
        subtitle_label = QLabel("Sistema di calcolo preventivi e statistiche RCS")
        subtitle_label.setAlignment(Qt.AlignCenter)
        subtitle_label.setWordWrap(True)
        subtitle_label.setStyleSheet(f"""
            QLabel {{
                font-size: {subtitle_size};
                font-weight: 400;
                color: #718096;
                padding: 0;
            }}
        """)

        header_layout.addWidget(title_label)
        header_layout.addWidget(subtitle_label)

        parent_layout.addWidget(header_container)
    
    @staticmethod
    def create_main_actions_column(window_instance, parent_layout):
        """Colonna principale con azioni principali"""
        main_column = QWidget()
        main_column.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        layout = QVBoxLayout(main_column)
        layout.setSpacing(20)
        
        # Sezione azioni principali
        actions_group = QGroupBox("Azioni Principali")
        actions_group.setGraphicsEffect(MainWindowUIComponents.create_shadow_effect())
        
        screen = QApplication.primaryScreen().availableGeometry()
        small_screen = screen.height() <= 800
        pad = 16 if small_screen else 30
        top_pad = 20 if small_screen else 35

        actions_layout = QVBoxLayout(actions_group)
        actions_layout.setContentsMargins(pad, top_pad, pad, pad)
        actions_layout.setSpacing(12 if small_screen else 20)
        
        # Pulsanti principali
        MainWindowUIComponents.create_main_buttons(window_instance, actions_layout)
        
        layout.addWidget(actions_group)
        layout.addStretch()
        
        parent_layout.addWidget(main_column)
        window_instance.main_column = main_column
    
    @staticmethod
    def create_main_buttons(window_instance, parent_layout):
        """Pulsanti principali standardizzati"""
        screen = QApplication.primaryScreen().availableGeometry()
        small_screen = screen.height() <= 800
        btn_h = 40 if small_screen else 50
        font_main = "14px" if small_screen else "16px"
        font_db = "12px" if small_screen else "13px"
        btn_db_h = 32 if small_screen else 38

        buttons_layout = QVBoxLayout()
        buttons_layout.setSpacing(10 if small_screen else 16)

        # Pulsante Nuovo Preventivo - primario
        window_instance.btn_nuovo_preventivo = QPushButton("Calcola Nuovo Preventivo")
        window_instance.btn_nuovo_preventivo.setMinimumHeight(btn_h)
        window_instance.btn_nuovo_preventivo.setStyleSheet(f"""
            QPushButton {{
                background-color: #4a5568;
                color: #ffffff;
                min-height: {btn_h}px;
                font-size: {font_main};
                font-weight: 600;
            }}
            QPushButton:hover {{ background-color: #2d3748; }}
            QPushButton:pressed {{ background-color: #1a202c; }}
        """)
        window_instance.btn_nuovo_preventivo.clicked.connect(window_instance.apri_preventivo)

        # Stile secondario riutilizzabile
        style_secondary = f"""
            QPushButton {{
                background-color: #f7fafc;
                color: #4a5568;
                border: 1px solid #e2e8f0;
                min-height: {btn_h}px;
                font-size: {font_main};
                font-weight: 600;
            }}
            QPushButton:hover {{ background-color: #edf2f7; }}
            QPushButton:pressed {{ background-color: #e2e8f0; }}
        """

        window_instance.btn_visualizza_preventivi = QPushButton("Visualizza Preventivi Salvati")
        window_instance.btn_visualizza_preventivi.setMinimumHeight(btn_h)
        window_instance.btn_visualizza_preventivi.setStyleSheet(style_secondary)
        window_instance.btn_visualizza_preventivi.clicked.connect(window_instance.mostra_nascondi_preventivi)

        window_instance.btn_gestisci_materiali = QPushButton("Gestisci Materiali")
        window_instance.btn_gestisci_materiali.setMinimumHeight(btn_h)
        window_instance.btn_gestisci_materiali.setStyleSheet(style_secondary)
        window_instance.btn_gestisci_materiali.clicked.connect(window_instance.apri_gestione_materiali)

        window_instance.btn_gestisci_magazzino = QPushButton("Gestisci Magazzino")
        window_instance.btn_gestisci_magazzino.setMinimumHeight(btn_h)
        window_instance.btn_gestisci_magazzino.setStyleSheet(style_secondary)
        window_instance.btn_gestisci_magazzino.clicked.connect(window_instance.apri_magazzino)

        window_instance.btn_anagrafica_clienti = QPushButton("Anagrafica Clienti")
        window_instance.btn_anagrafica_clienti.setMinimumHeight(btn_h)
        window_instance.btn_anagrafica_clienti.setStyleSheet(style_secondary)
        window_instance.btn_anagrafica_clienti.clicked.connect(window_instance.apri_anagrafica_clienti)

        # Separatore
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setFrameShadow(QFrame.Sunken)
        sep.setStyleSheet("color: #e2e8f0;")

        # Pulsante Cambia Database
        window_instance.btn_cambia_database = QPushButton("Cambia Database")
        window_instance.btn_cambia_database.setMinimumHeight(btn_db_h)
        window_instance.btn_cambia_database.setStyleSheet(f"""
            QPushButton {{
                background-color: #fff8e1;
                color: #7b5e00;
                border: 1px solid #f6e05e;
                min-height: {btn_db_h}px;
                font-size: {font_db};
                font-weight: 500;
            }}
            QPushButton:hover {{ background-color: #fef3c7; }}
            QPushButton:pressed {{ background-color: #fde68a; }}
        """)
        window_instance.btn_cambia_database.setToolTip(
            "Seleziona un database diverso (es. cartella condivisa in rete)"
        )
        window_instance.btn_cambia_database.clicked.connect(window_instance.cambia_database)

        buttons_layout.addWidget(window_instance.btn_nuovo_preventivo)
        buttons_layout.addWidget(window_instance.btn_visualizza_preventivi)
        buttons_layout.addWidget(window_instance.btn_gestisci_materiali)
        buttons_layout.addWidget(window_instance.btn_gestisci_magazzino)
        buttons_layout.addWidget(window_instance.btn_anagrafica_clienti)
        buttons_layout.addWidget(sep)
        buttons_layout.addWidget(window_instance.btn_cambia_database)

        parent_layout.addLayout(buttons_layout)

    @staticmethod
    def create_footer(window_instance, parent_layout):
        """Footer informativo"""
        footer_container = QFrame()
        footer_container.setStyleSheet("""
            QFrame {
                background-color: transparent;
                border: none;
                padding: 20px 0px;
            }
        """)
        
        footer_layout = QHBoxLayout(footer_container)
        footer_layout.setContentsMargins(0, 0, 0, 0)
        
        footer_label = QLabel("Software Aziendale RCS v2.3.0 | Sistema di calcolo preventivi, gestione revisioni e generazione documenti")
        footer_label.setWordWrap(True)
        footer_label.setStyleSheet("""
            QLabel {
                color: #a0aec0;
                font-size: 12px;
                font-weight: 400;
            }
        """)
        
        footer_layout.addWidget(footer_label)
        footer_layout.addStretch()
        
        parent_layout.addWidget(footer_container)